#!/bin/sh

# gcc –fpic -shared  -o libringbuffer.so  ringbuffer.c
# gcc  test test.c -o test.o
